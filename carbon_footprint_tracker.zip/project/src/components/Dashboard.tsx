import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, CarbonActivity } from '../lib/supabase';
import { LogOut, Plus, Leaf } from 'lucide-react';
import ActivityForm from './ActivityForm';
import ActivityList from './ActivityList';
import Statistics from './Statistics';

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const [activities, setActivities] = useState<CarbonActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadActivities();
  }, [user]);

  const loadActivities = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('carbon_activities')
      .select('*')
      .order('date', { ascending: false });

    if (!error && data) {
      setActivities(data);
    }
    setLoading(false);
  };

  const handleActivityAdded = () => {
    setShowForm(false);
    loadActivities();
  };

  const handleActivityDeleted = () => {
    loadActivities();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-800">Carbon Footprint Tracker</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">{user?.email}</span>
              <button
                onClick={() => signOut()}
                className="flex items-center space-x-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Statistics activities={activities} />

        <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Activities</h2>
            <button
              onClick={() => setShowForm(!showForm)}
              className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition font-medium"
            >
              <Plus className="w-5 h-5" />
              <span>Add Activity</span>
            </button>
          </div>

          {showForm && (
            <div className="mb-6">
              <ActivityForm onSuccess={handleActivityAdded} onCancel={() => setShowForm(false)} />
            </div>
          )}

          {loading ? (
            <div className="text-center py-12 text-gray-500">Loading activities...</div>
          ) : activities.length === 0 ? (
            <div className="text-center py-12">
              <Leaf className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No activities yet</p>
              <p className="text-gray-400 text-sm mt-2">Start tracking your carbon footprint by adding an activity</p>
            </div>
          ) : (
            <ActivityList activities={activities} onDelete={handleActivityDeleted} />
          )}
        </div>
      </main>
    </div>
  );
}
