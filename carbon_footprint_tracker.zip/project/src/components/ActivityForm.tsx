import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { X } from 'lucide-react';

interface ActivityFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const activityTypes = {
  transportation: {
    label: 'Transportation',
    categories: {
      car: { label: 'Car (Gasoline)', unit: 'km', factor: 0.192 },
      electric_car: { label: 'Car (Electric)', unit: 'km', factor: 0.053 },
      bus: { label: 'Bus', unit: 'km', factor: 0.089 },
      train: { label: 'Train', unit: 'km', factor: 0.041 },
      flight_short: { label: 'Flight (Short-haul)', unit: 'km', factor: 0.255 },
      flight_long: { label: 'Flight (Long-haul)', unit: 'km', factor: 0.195 },
      motorcycle: { label: 'Motorcycle', unit: 'km', factor: 0.113 },
    },
  },
  energy: {
    label: 'Energy',
    categories: {
      electricity: { label: 'Electricity', unit: 'kWh', factor: 0.475 },
      natural_gas: { label: 'Natural Gas', unit: 'm³', factor: 2.0 },
      heating_oil: { label: 'Heating Oil', unit: 'L', factor: 2.68 },
    },
  },
  food: {
    label: 'Food',
    categories: {
      beef: { label: 'Beef', unit: 'kg', factor: 27.0 },
      lamb: { label: 'Lamb', unit: 'kg', factor: 39.2 },
      pork: { label: 'Pork', unit: 'kg', factor: 12.1 },
      chicken: { label: 'Chicken', unit: 'kg', factor: 6.9 },
      fish: { label: 'Fish', unit: 'kg', factor: 6.1 },
      dairy: { label: 'Dairy', unit: 'kg', factor: 3.2 },
      vegetables: { label: 'Vegetables', unit: 'kg', factor: 2.0 },
    },
  },
  waste: {
    label: 'Waste',
    categories: {
      landfill: { label: 'Landfill Waste', unit: 'kg', factor: 0.57 },
      recycling: { label: 'Recycling', unit: 'kg', factor: 0.21 },
    },
  },
};

export default function ActivityForm({ onSuccess, onCancel }: ActivityFormProps) {
  const { user } = useAuth();
  const [activityType, setActivityType] = useState('transportation');
  const [category, setCategory] = useState('car');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const selectedCategory = activityTypes[activityType as keyof typeof activityTypes].categories[
    category as keyof typeof activityTypes.transportation.categories
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setError('');
    setLoading(true);

    const carbonKg = parseFloat(amount) * selectedCategory.factor;

    const { error } = await supabase.from('carbon_activities').insert({
      user_id: user.id,
      activity_type: activityType,
      category,
      amount: parseFloat(amount),
      unit: selectedCategory.unit,
      carbon_kg: carbonKg,
      date,
      notes,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      onSuccess();
    }
  };

  const handleTypeChange = (newType: string) => {
    setActivityType(newType);
    const firstCategory = Object.keys(activityTypes[newType as keyof typeof activityTypes].categories)[0];
    setCategory(firstCategory);
  };

  return (
    <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Add New Activity</h3>
        <button onClick={onCancel} className="text-gray-400 hover:text-gray-600">
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Activity Type
            </label>
            <select
              value={activityType}
              onChange={(e) => handleTypeChange(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
            >
              {Object.entries(activityTypes).map(([key, { label }]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
            >
              {Object.entries(
                activityTypes[activityType as keyof typeof activityTypes].categories
              ).map(([key, { label }]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Amount ({selectedCategory.unit})
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Notes (Optional)
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none resize-none"
            placeholder="Add any additional details..."
          />
        </div>

        {amount && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-gray-700">
              Estimated carbon emissions:{' '}
              <span className="font-bold text-green-700">
                {(parseFloat(amount) * selectedCategory.factor).toFixed(2)} kg CO₂
              </span>
            </p>
          </div>
        )}

        <div className="flex space-x-3 pt-2">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Adding...' : 'Add Activity'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
