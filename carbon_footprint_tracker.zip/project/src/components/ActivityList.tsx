import { CarbonActivity, supabase } from '../lib/supabase';
import { Trash2, Calendar, TrendingUp } from 'lucide-react';
import { useState } from 'react';

interface ActivityListProps {
  activities: CarbonActivity[];
  onDelete: () => void;
}

export default function ActivityList({ activities, onDelete }: ActivityListProps) {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this activity?')) return;

    setDeletingId(id);
    const { error } = await supabase.from('carbon_activities').delete().eq('id', id);

    if (!error) {
      onDelete();
    }
    setDeletingId(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const getCategoryLabel = (activityType: string, category: string) => {
    const labels: Record<string, Record<string, string>> = {
      transportation: {
        car: 'Car (Gasoline)',
        electric_car: 'Car (Electric)',
        bus: 'Bus',
        train: 'Train',
        flight_short: 'Flight (Short-haul)',
        flight_long: 'Flight (Long-haul)',
        motorcycle: 'Motorcycle',
      },
      energy: {
        electricity: 'Electricity',
        natural_gas: 'Natural Gas',
        heating_oil: 'Heating Oil',
      },
      food: {
        beef: 'Beef',
        lamb: 'Lamb',
        pork: 'Pork',
        chicken: 'Chicken',
        fish: 'Fish',
        dairy: 'Dairy',
        vegetables: 'Vegetables',
      },
      waste: {
        landfill: 'Landfill Waste',
        recycling: 'Recycling',
      },
    };

    return labels[activityType]?.[category] || category;
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Type</th>
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Category</th>
            <th className="text-right py-3 px-4 font-semibold text-gray-700">Amount</th>
            <th className="text-right py-3 px-4 font-semibold text-gray-700">CO₂ Emissions</th>
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Notes</th>
            <th className="w-16"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {activities.map((activity) => (
            <tr key={activity.id} className="hover:bg-gray-50 transition">
              <td className="py-3 px-4">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">{formatDate(activity.date)}</span>
                </div>
              </td>
              <td className="py-3 px-4">
                <span className="inline-flex px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 capitalize">
                  {activity.activity_type}
                </span>
              </td>
              <td className="py-3 px-4 text-sm text-gray-700">
                {getCategoryLabel(activity.activity_type, activity.category)}
              </td>
              <td className="py-3 px-4 text-right text-sm text-gray-700">
                {activity.amount} {activity.unit}
              </td>
              <td className="py-3 px-4 text-right">
                <div className="flex items-center justify-end space-x-1 text-gray-700 font-medium">
                  <TrendingUp className="w-4 h-4 text-orange-500" />
                  <span>{activity.carbon_kg.toFixed(2)} kg</span>
                </div>
              </td>
              <td className="py-3 px-4 text-sm text-gray-500 max-w-xs truncate">
                {activity.notes || '-'}
              </td>
              <td className="py-3 px-4">
                <button
                  onClick={() => handleDelete(activity.id)}
                  disabled={deletingId === activity.id}
                  className="text-red-600 hover:text-red-700 disabled:opacity-50"
                  title="Delete activity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
