import { CarbonActivity } from '../lib/supabase';
import { TrendingUp, Zap, Car, UtensilsCrossed, Trash2 } from 'lucide-react';

interface StatisticsProps {
  activities: CarbonActivity[];
}

export default function Statistics({ activities }: StatisticsProps) {
  const totalEmissions = activities.reduce((sum, activity) => sum + Number(activity.carbon_kg), 0);

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const monthlyEmissions = activities
    .filter((activity) => {
      const activityDate = new Date(activity.date);
      return activityDate.getMonth() === currentMonth && activityDate.getFullYear() === currentYear;
    })
    .reduce((sum, activity) => sum + Number(activity.carbon_kg), 0);

  const emissionsByType = activities.reduce((acc, activity) => {
    acc[activity.activity_type] = (acc[activity.activity_type] || 0) + Number(activity.carbon_kg);
    return acc;
  }, {} as Record<string, number>);

  const typeIcons: Record<string, typeof Car> = {
    transportation: Car,
    energy: Zap,
    food: UtensilsCrossed,
    waste: Trash2,
  };

  const typeColors: Record<string, string> = {
    transportation: 'bg-blue-100 text-blue-700',
    energy: 'bg-yellow-100 text-yellow-700',
    food: 'bg-green-100 text-green-700',
    waste: 'bg-gray-100 text-gray-700',
  };

  const stats = [
    {
      label: 'Total Emissions',
      value: `${totalEmissions.toFixed(2)} kg`,
      subtext: 'All time',
      icon: TrendingUp,
      color: 'bg-orange-100 text-orange-700',
    },
    {
      label: 'This Month',
      value: `${monthlyEmissions.toFixed(2)} kg`,
      subtext: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      icon: TrendingUp,
      color: 'bg-green-100 text-green-700',
    },
  ];

  const equivalents = [
    {
      label: 'Trees needed to offset',
      value: Math.ceil(totalEmissions / 21.77),
      subtext: 'Based on annual CO₂ absorption',
    },
    {
      label: 'Car miles equivalent',
      value: Math.round(totalEmissions / 0.404),
      subtext: 'Average gasoline vehicle',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-3">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.subtext}</p>
              </div>
            </div>
          );
        })}

        {Object.entries(emissionsByType).map(([type, emissions]) => {
          const Icon = typeIcons[type];
          const colorClass = typeColors[type];
          return (
            <div key={type} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-3">
                <div className={`p-3 rounded-lg ${colorClass}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1 capitalize">{type}</p>
                <p className="text-2xl font-bold text-gray-800 mb-1">{emissions.toFixed(2)} kg</p>
                <p className="text-xs text-gray-500">
                  {((emissions / totalEmissions) * 100).toFixed(1)}% of total
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {totalEmissions > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Environmental Impact</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {equivalents.map((equiv) => (
              <div key={equiv.label} className="flex items-center space-x-4">
                <div className="flex-1">
                  <p className="text-3xl font-bold text-green-600">{equiv.value.toLocaleString()}</p>
                  <p className="text-sm font-medium text-gray-700 mt-1">{equiv.label}</p>
                  <p className="text-xs text-gray-500 mt-1">{equiv.subtext}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
