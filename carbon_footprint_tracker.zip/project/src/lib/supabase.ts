import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface CarbonActivity {
  id: string;
  user_id: string;
  activity_type: string;
  category: string;
  amount: number;
  unit: string;
  carbon_kg: number;
  date: string;
  notes: string;
  created_at: string;
}
