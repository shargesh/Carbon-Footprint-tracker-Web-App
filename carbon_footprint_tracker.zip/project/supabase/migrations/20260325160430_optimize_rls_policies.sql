/*
  # Optimize RLS Policies for Performance

  1. Changes
    - Replace direct auth.uid() calls with (select auth.uid()) in all policies
    - This prevents re-evaluation of auth functions for each row, improving query performance at scale
    - Fixes performance issue identified in Supabase security audit

  2. Policies Updated
    - "Users can view own activities" - SELECT policy
    - "Users can insert own activities" - INSERT policy
    - "Users can update own activities" - UPDATE policy
    - "Users can delete own activities" - DELETE policy
*/

DROP POLICY IF EXISTS "Users can view own activities" ON carbon_activities;
DROP POLICY IF EXISTS "Users can insert own activities" ON carbon_activities;
DROP POLICY IF EXISTS "Users can update own activities" ON carbon_activities;
DROP POLICY IF EXISTS "Users can delete own activities" ON carbon_activities;

CREATE POLICY "Users can view own activities"
  ON carbon_activities FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own activities"
  ON carbon_activities FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own activities"
  ON carbon_activities FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own activities"
  ON carbon_activities FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));