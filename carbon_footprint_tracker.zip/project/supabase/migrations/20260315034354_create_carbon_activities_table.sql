/*
  # Carbon Footprint Tracker Schema

  1. New Tables
    - `carbon_activities`
      - `id` (uuid, primary key) - Unique identifier for each activity
      - `user_id` (uuid, foreign key) - References auth.users
      - `activity_type` (text) - Type of activity (transportation, energy, food, waste)
      - `category` (text) - Specific category (e.g., car, flight, electricity, meat)
      - `amount` (decimal) - Quantity of the activity
      - `unit` (text) - Unit of measurement (km, kwh, kg, etc.)
      - `carbon_kg` (decimal) - Carbon emissions in kilograms
      - `date` (date) - Date of the activity
      - `notes` (text, optional) - Additional notes
      - `created_at` (timestamptz) - Timestamp when record was created

  2. Security
    - Enable RLS on `carbon_activities` table
    - Add policy for users to read their own activities
    - Add policy for users to insert their own activities
    - Add policy for users to update their own activities
    - Add policy for users to delete their own activities
*/

CREATE TABLE IF NOT EXISTS carbon_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  activity_type text NOT NULL,
  category text NOT NULL,
  amount decimal NOT NULL,
  unit text NOT NULL,
  carbon_kg decimal NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE carbon_activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own activities"
  ON carbon_activities FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activities"
  ON carbon_activities FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own activities"
  ON carbon_activities FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own activities"
  ON carbon_activities FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_carbon_activities_user_date 
  ON carbon_activities(user_id, date DESC);